# Motion Designer Showreel

15-second 1920×1080 motion-design reel built with HTML, CSS, SVG textures, GSAP, and HyperFrames.

## Preview

Open `index.html` through HyperFrames Studio with `npm run dev`.

## Validate and render

```sh
npm run check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx hyperframes render --output motion-showreel.mp4 --fps 30 --quality high
```

Replace `hello@yourstudio.com` in `index.html` with the final contact address before publishing.
